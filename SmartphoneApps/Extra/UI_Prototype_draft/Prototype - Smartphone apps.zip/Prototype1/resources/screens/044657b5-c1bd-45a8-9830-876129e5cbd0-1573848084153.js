jQuery("#simulation")
  .on("click", ".s-044657b5-c1bd-45a8-9830-876129e5cbd0 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Image_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-condition_Select" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Menu-maximum-width" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7 > .backgroundLayer": {
                      "attributes": {
                        "box-shadow": "0px 5px 15px 0px #999999"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#6200EE",
                        "background-attachment": "scroll",
                        "box-shadow": "0px 2px 5px 0px #999999"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7": {
                      "attributes-ie": {
                        "-pie-background": "#6200EE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 100
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EEEEEE",
                        "box-shadow": "0px 3px 4px 0px #A0A0A0"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8 span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8": {
                      "attributes-ie": {
                        "-pie-background": "#EEEEEE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8 > .backgroundLayer": {
                      "attributes": {
                        "box-shadow": "0px 5px 15px 0px #999999"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#6200EE",
                        "box-shadow": "0px 2px 5px 0px #999999"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8 span": {
                      "attributes": {
                        "color": "#FFFFFF"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_8": {
                      "attributes-ie": {
                        "-pie-background": "#6200EE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 100
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EEEEEE",
                        "background-attachment": "scroll",
                        "box-shadow": "0px 2px 5px 0px #999999"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7": {
                      "attributes": {
                        "text-shadow": "none"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7 span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Button_7": {
                      "attributes-ie": {
                        "-pie-background": "#EEEEEE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Triangle")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Item_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Item_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F0E8FC",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Item_3": {
                      "attributes-ie": {
                        "-pie-background": "#F0E8FC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Item_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Item_3": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 500
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-condition_Select" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Menu-maximum-width" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Item_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Item_4 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F0E8FC",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Item_4": {
                      "attributes-ie": {
                        "-pie-background": "#F0E8FC",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Item_4 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FFFFFF",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-044657b5-c1bd-45a8-9830-876129e5cbd0 #s-Item_4": {
                      "attributes-ie": {
                        "-pie-background": "#FFFFFF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 500
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });