(function(window, undefined) {

  var jimLinks = {
    "3f8a86d3-8458-409d-b410-71450f92c022" : {
      "Triangle" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "3f8a86d3-8458-409d-b410-71450f92c022"
      ],
      "Button_2" : [
        "4b3f7664-f600-4f27-85d0-b12c64330d33"
      ],
      "Image_72" : [
        "044657b5-c1bd-45a8-9830-876129e5cbd0"
      ]
    },
    "4b3f7664-f600-4f27-85d0-b12c64330d33" : {
      "Triangle" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "044657b5-c1bd-45a8-9830-876129e5cbd0" : {
      "Triangle" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);