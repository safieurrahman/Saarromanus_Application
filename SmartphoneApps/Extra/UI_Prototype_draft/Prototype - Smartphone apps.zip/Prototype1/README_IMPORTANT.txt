Steps to use the prototype:

1. Extract the Prototype1.zip file

2. Open index.html file using Chrome

3. Click on Download Extension button

4. Once downloade, right click on the newly added extension icon and select Manage Extensions.

5. On the Manage Extension page, Allow this extension File URL Read access.

6. Go back to the index.html again.

7. Scroll down to the bottom of the page and select View
